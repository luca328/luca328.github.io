pour installer l'app il y 2 étape :3

étape 1
installer git (y'a déjà l'installeur et laisser les paramèrtres par défaut)

étape 2
lancé le install.bat
(on croise les doigts pour que ça marche)