<?php 

$servername = "localhost";
$database = "thunderProject";
$username = "root";
$password = "root";
$charset = "utf8mb4";

try {
    $dsn = "mysql:host=$servername;dbname=$database;charset=$charset";
    $pdo = new PDO($dsn, $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
} ?>


<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.4.1/dist/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">

    <!-- Optional theme -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.4.1/dist/css/bootstrap-theme.min.css" integrity="sha384-6pzBo3FDv/PJ8r2KRkGHifhEocL+1X2rVCTTkUfGk7/0pbek5mMa1upzvWbrUbOZ" crossorigin="anonymous">

    <!-- Latest compiled and minified JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@3.4.1/dist/js/bootstrap.min.js" integrity="sha384-aJ21OjlMXNL5UyIl/XNwTMqvzeRMZH2w8c5cRVpzpU8Y5bApTppSuUkhZXN0VxHd" crossorigin="anonymous"></script>


</head>

    <body>
        <main>
            <?php
            $RPTotal=0;
            $victoire=0;
            $nbBataille=0;
            $kill=0;
            $SLTotal=0;
            $result = $pdo->query("SELECT * FROM bataille ORDER BY  id ASC");?>
            <form>
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">ID</th>
                            <th scope="col">Résultat</th>
                            <th scope="col">RP</th>
                            <th scope="col">SL</th>
                            <th scope="col">Tank détruit</th>
                            <th scope="col">Avion détruit</th>
                            <th scope="col">Assistance</th>
                            <th scope="col">Réparation</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($bataille = $result->fetch(PDO::FETCH_OBJ)) { 
                            $id=$bataille->id;
                            $nbBataille++?>
                            <tr>
                                <td scope="row"><?php echo $id ?></td>
                                <td><?php if (1 == $bataille->resultat) {
                                    echo "Victoire";
                                    $victoire=$victoire+100;
                                } else {
                                    echo "Défaite";
                                } ?></td>
                                <td><?php echo $bataille->RP; $RPTotal=$RPTotal+$bataille->RP;?></td>
                                <td><?php echo $bataille->SL;$SLTotal=$SLTotal+$bataille->SL ?></td>
                                <td><?php echo $bataille->tank; $kill=$kill+$bataille->tank ?></td>
                                <td><?php echo $bataille->avion; $kill=$kill+$bataille->avion ?></td>
                                <td><?php echo $bataille->assist ?></td>
                                <td><a class="btn btn-primary" href="update_bataille.php?id=<?php echo $id ?>" role="button">Modifier</a></td>
                                <td><a class="btn btn-danger" href="delete_bataille.php?id=<?php echo $id ?>" role="button">Supprimer</a></td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </form>
            <div class="form-group col-md-3">
                <label for="RP total">RP total</label>
                <b>&nbsp; <?php echo $RPTotal ?></b>
            </div>
            <div class="form-group col-md-3">
                <label for="SL total">SL total</label>
                <b>&nbsp; <?php echo $SLTotal ?></b>
            </div>
            <div class="form-group col-md-3">
                <label for="kill">Nombre de kill total</label>
                <b>&nbsp; <?php echo $kill ?></b>
            </div>
            <div class="form-group col-md-3 ">
                <label for="win rate">Win rate</label>
                <b>&nbsp; <?php if(0 == $nbBataille) {echo 0; } else {echo $victoire/$nbBataille;} ?> %</b>
            </div>
            <a class="btn btn-primary" href="create_bataille.php" role="button">Ajouter une bataille</a>
            <button type="submit" class="btn btn-danger" role="button"><?php $pdo->exec("TRUNCATE table bataille"); ?>purge BDD</a>
        </main>
    </body>
</html>