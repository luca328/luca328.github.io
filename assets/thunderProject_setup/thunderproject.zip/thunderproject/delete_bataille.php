<?php
$servername = "localhost";
$database = "thunderProject";
$username = "root";
$password = "root";
$charset = "utf8mb4";

try {
    $dsn = "mysql:host=$servername;dbname=$database;charset=$charset";
    $pdo = new PDO($dsn, $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}

if(isset($_GET['id']) && !empty($_GET['id'])){
    $id = $_GET['id'];

    $pdo->exec("DELETE FROM bataille WHERE id='$id';");

    header('Location: /');
}
?>