<?php 
$servername = "localhost";
$database = "thunderProject";
$username = "root";
$password = "root";
$charset = "utf8mb4";

try {
    $dsn = "mysql:host=$servername;dbname=$database;charset=$charset";
    $pdo = new PDO($dsn, $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
} ?>


<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta charset="UTF-8">
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.4.1/dist/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">

        <!-- Optional theme -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.4.1/dist/css/bootstrap-theme.min.css" integrity="sha384-6pzBo3FDv/PJ8r2KRkGHifhEocL+1X2rVCTTkUfGk7/0pbek5mMa1upzvWbrUbOZ" crossorigin="anonymous">

        <!-- Latest compiled and minified JavaScript -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@3.4.1/dist/js/bootstrap.min.js" integrity="sha384-aJ21OjlMXNL5UyIl/XNwTMqvzeRMZH2w8c5cRVpzpU8Y5bApTppSuUkhZXN0VxHd" crossorigin="anonymous"></script>


    </head>

    <body>
        <main>
    <?php

        if (isset($_POST['resultat'])){
                $resultat = strip_tags($_POST['resultat']);
                $RP = strip_tags($_POST['RP']);
                $SL = strip_tags($_POST['SL']);
                $tank = strip_tags($_POST['tank']);
                $avion = strip_tags($_POST['avion']);
                $assist = strip_tags($_POST['assist']);
        //  $sql = "INSERT INTO bataille(resultat, RP, SL, tank, avion, assist, reparation) VALUES ( $name, $RP, $SL, $tank, $avion, $assist, $reparation)";

        $pdo->exec("INSERT INTO bataille(resultat, RP, SL, tank, avion, assist) VALUES ( '$resultat', '$RP', '$SL', '$tank', '$avion', '$assist')");
        header('Location: index.php');
    }
    ?>
            <h1>Créer une nouvelle bataille</h1>
            <form method="POST">
                <div class="form-row">
                    <div class="form-group">
                        <label for="resultat">Résultat</label>
                        <select name="resultat" id="resultat">
                            <option value="1">Victoire</option>
                            <option value="0">Défaite</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="SL">SL</label>
                        <input required type="number" class="form-control" name="SL" placeholder="SL">
                    </div>
                    <div class="form-group">
                        <label for="RP">RP</label>
                        <input required type="number" min="0" class="form-control" name="RP" placeholder="RP">
                    </div>
                    <div class="form-group">
                        <label for="tank">tank</label>
                        <input required type="number" min="0" class="form-control" name="tank" placeholder="tank">
                    </div>
                    <div class="form-group">
                        <label for="avion">avion</label>
                        <input required type="number" min="0" class="form-control" name="avion" placeholder="avion">
                    </div>
                    <div class="form-group">
                        <label for="assist">assist</label>
                        <input required type="number" min="0" class="form-control" name="assist" placeholder="assist">
                    </div>
                </div>
                <button type="submit" name="submit" class="btn btn-primary">Envoyer</button>
                <a class="btn btn-primary" href="/">retour</a>
            </form>
        </main>
    </body>
</html>
